from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import random

key = str(random.randint(0, 9999)).zfill(16).encode()
msg = input("Enter message: ").encode()

aes = AES.new(key, AES.MODE_ECB)
enc = aes.encrypt(pad(msg, 16))
dec = unpad(aes.decrypt(enc), 16)

print("AES SymmetricKey:", key.decode())
print("Encrypted message:", enc.hex())
print("Decrypted message:", dec.decode())
