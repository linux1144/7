from Crypto.Cipher import DES
from Crypto.Util.Padding import pad,unpad

key = b"12345678"
msg = input("Message: ").encode()

c = DES.new(key,DES.MODE_ECB)
enc = c.encrypt(pad(msg,8))

print("Encrypted:",enc.hex())
print("Decrypted:",unpad(c.decrypt(enc),8).decode())
