from itertools import cycle

def vig(t,k,s=1):
    return ''.join(chr((ord(a)-65+s*(ord(b)-65))%26+65)
                   for a,b in zip(t,cycle(k)))

msg = "HELLOWORLD"
key = "KEY"

enc = vig(msg,key)
print("Encrypted:",enc)
print("Decrypted:",vig(enc,key,-1))
