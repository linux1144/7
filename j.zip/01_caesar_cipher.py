import string

a = string.ascii_lowercase
msg = input("Enter text: ").lower()
k = int(input("Enter key: "))

def caesar(t,k):
    return t.translate(str.maketrans(a,a[k%26:]+a[:k%26]))

enc = caesar(msg,k)
print("Encrypted:",enc)
print("Decrypted:",caesar(enc,-k))
