p,q,g = 10601,53,6084
x,k,h = 25,46,15206

y = pow(g,x,p)
r = pow(g,k,p)%q
s = (pow(k,-1,q)*(h+x*r))%q

w = pow(s,-1,q)
u1,u2 = h*w%q,r*w%q
v = (pow(g,u1,p)*pow(y,u2,p)%p)%q

print("Public Key:",y)
print("Signature:",r,s)
print("Verification:",v)
print("Verified!" if v==r else "Invalid!")
