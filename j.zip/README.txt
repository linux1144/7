INFORMATION SECURITY LAB — 10 PYTHON PROGRAMS
================================================

Files
-----
01_caesar_cipher.py       Caesar Cipher
02_playfair_cipher.py     Playfair Cipher
03_hill_cipher.py         Hill Cipher
04_vigenere_cipher.py     Vigenere Cipher
05_des.py                 DES Encryption and Decryption
06_aes.py                 AES Encryption and Decryption
07_rsa_flask.py           RSA using Flask
08_sha1.py                SHA-1 Hashing
09_dsa.py                 Digital Signature Algorithm
10_diffie_hellman.py      Diffie-Hellman Key Exchange

Requirements
------------
Python 3

Install required packages:
    python3 -m pip install numpy pycryptodome flask

Run individual programs
-----------------------
    python3 01_caesar_cipher.py
    python3 02_playfair_cipher.py
    python3 03_hill_cipher.py
    python3 04_vigenere_cipher.py
    python3 05_des.py
    python3 06_aes.py
    python3 07_rsa_flask.py
    python3 08_sha1.py
    python3 09_dsa.py
    python3 10_diffie_hellman.py

RSA Flask program
-----------------
Run:
    python3 07_rsa_flask.py

Then open this address in a browser:
    http://127.0.0.1:5000

Notes
-----
- The Vigenere program uses the fixed plaintext HELLOWORLD and key KEY,
  matching the supplied short version.
- Hill Cipher adds X padding when the plaintext length is odd. The
  decrypted output therefore retains the padding X.
- Playfair combines I/J and may retain filler X characters after decryption.
- DES and AES use ECB mode here for classroom demonstration only.
  ECB is not recommended for real-world encryption.
- The AES example uses Python's random module for a simple lab key;
  it is not suitable for generating production cryptographic keys.
- The RSA example is textbook RSA for demonstration and assumes valid,
  distinct prime inputs. It does not implement production-safe padding.
- The DSA example uses fixed classroom parameters and a fixed nonce.
  Never reuse a DSA nonce in real cryptographic systems.
- SHA-1 is obsolete for collision-resistant security applications.

These programs are educational demonstrations, not production security tools.
