p = int(input("Prime: "))
g = int(input("Root: "))
x = int(input("Sender key: "))
y = int(input("Receiver key: "))

r1,r2 = pow(g,x,p),pow(g,y,p)
k1,k2 = pow(r2,x,p),pow(r1,y,p)

print("R1:",r1,"R2:",r2)
print("Sender Key:",k1)
print("Receiver Key:",k2)
print("Shared Key:",k1 if k1==k2 else "Error")
