import hashlib

msg = input("Enter text: ")
digest = hashlib.sha1(msg.encode()).hexdigest()

print("Input Text:",msg)
print("SHA-1 Digest:",digest)
