import string

key = input("Key: ").upper().replace("J","I")
abc = ''.join(dict.fromkeys(
    key + string.ascii_uppercase.replace("J","")))
abc = ''.join(c for c in abc if c.isalpha())[:25]

def prepare(t):
    t = ''.join(c for c in t.upper().replace("J","I") if c.isalpha())
    out = ""
    while t:
        a = t[0]
        b = t[1] if len(t)>1 and t[1]!=a else "X"
        out += a+b
        t = t[2:] if len(t)>1 and t[1]!=a else t[1:]
    return out

def play(t,k):
    out = ""
    for a,b in zip(t[::2],t[1::2]):
        r,c = divmod(abc.index(a),5)
        s,d = divmod(abc.index(b),5)
        if r==s: c,d = (c+k)%5,(d+k)%5
        elif c==d: r,s = (r+k)%5,(s+k)%5
        else: c,d = d,c
        out += abc[r*5+c]+abc[s*5+d]
    return out

msg = prepare(input("Text: "))
enc = play(msg,1)
print("Encrypted:",enc)
print("Decrypted:",play(enc,-1))
