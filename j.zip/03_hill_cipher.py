import numpy as np

K = np.array([[3,3],[2,5]])
I = np.array([[15,17],[20,9]])

def hill(t,k):
    a = np.array([ord(c)-65 for c in t])
    return ''.join(chr(x+65) for x in
        (a.reshape(-1,2) @ k.T % 26).flatten())

msg = input("Text: ").upper().replace(" ","")
msg += "X"*(len(msg)%2)

enc = hill(msg,K)
print("Encrypted:",enc)
print("Decrypted:",hill(enc,I))
