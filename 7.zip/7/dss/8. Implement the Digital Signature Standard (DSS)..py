import hashlib, secrets

p, q, g = 10601, 53, 6084
x = secrets.randbelow(q-1)+1
y = pow(g,x,p)

m = open(input("Enter document filename: "),"rb").read()
h = int(hashlib.sha256(m).hexdigest(),16)

while True:
    k = secrets.randbelow(q-1)+1
    r = pow(g,k,p)%q
    s = (pow(k,-1,q)*(h+x*r))%q
    if r and s:
        break

w = pow(s,-1,q)
v = (pow(g,h*w%q,p)*pow(y,r*w%q,p)%p)%q

print("Signature:",r,s)
print("Verification:","Valid" if v==r else "Invalid")