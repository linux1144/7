text = input("Enter plaintext: ").upper()
key = input("Enter keyword: ").upper()

print("Repeated key:", (key * (len(text)//len(key)+1))[:len(text)])