text = input("Enter plaintext: ")
key = int(input("Enter shift key: ")) % 26

cipher = ''.join(chr((ord(c)-97+key)%26+97)
                 if c.isalpha() and c.isascii() else c
                 for c in text.lower())

print("Encrypted:", cipher)