K = [[3,3],[2,5]]
D = [[15,17],[20,9]]

def hill(s,m):
    r = ""
    for i in range(0,len(s),2):
        a,b = ord(s[i])-65,ord(s[i+1])-65
        r += chr((m[0][0]*a+m[0][1]*b)%26+65)
        r += chr((m[1][0]*a+m[1][1]*b)%26+65)
    return r

p = ''.join(c for c in input("Plaintext: ").upper() if c.isalpha())
p += 'X'*(len(p)%2)

c = hill(p,K)
print("Padded:",p)
print("Encrypted:",c)
print("Decrypted:",hill(c,D))