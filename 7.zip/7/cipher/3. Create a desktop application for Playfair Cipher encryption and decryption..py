import tkinter as tk

def matrix(key):
    s = ""
    for c in key.upper().replace("J","I")+"ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if c.isalpha() and c not in s:
            s += c
    return [s[i:i+5] for i in range(0,25,5)]

def playfair(text, m, mode):
    text = text.upper().replace("J","I")
    if mode == 1:
        t, i = "", 0
        while i < len(text):
            a = text[i]
            b = text[i+1] if i+1 < len(text) else "X"
            if a == b:
                b, i = "X", i+1
            else:
                i += 2
            t += a+b
        text = t

    r = ""
    for i in range(0,len(text),2):
        a,b = text[i:i+2]
        x = next((j,k) for j,row in enumerate(m) for k,c in enumerate(row) if c==a)
        y = next((j,k) for j,row in enumerate(m) for k,c in enumerate(row) if c==b)
        if x[0] == y[0]:
            r += m[x[0]][(x[1]+mode)%5]+m[y[0]][(y[1]+mode)%5]
        elif x[1] == y[1]:
            r += m[(x[0]+mode)%5][x[1]]+m[(y[0]+mode)%5][y[1]]
        else:
            r += m[x[0]][y[1]]+m[y[0]][x[1]]
    return r

def run(mode):
    try:
        m = matrix(key.get())
        result.set(playfair(msg.get(),m,mode))
    except:
        result.set("Enter valid text and keyword")

root = tk.Tk()
root.title("Playfair Cipher")

key = tk.StringVar()
msg = tk.StringVar()
result = tk.StringVar()

tk.Label(root,text="Keyword").pack()
tk.Entry(root,textvariable=key).pack()

tk.Label(root,text="Plaintext / Ciphertext").pack()
tk.Entry(root,textvariable=msg).pack()

tk.Button(root,text="Encrypt",command=lambda:run(1)).pack()
tk.Button(root,text="Decrypt",command=lambda:run(-1)).pack()

tk.Label(root,textvariable=result).pack()

root.mainloop()