def generate_key(text, key):
    return (key * (len(text)//len(key)+1))[:len(text)]

def encrypt(text, key):
    return ''.join(chr((ord(a)+ord(b)-130)%26+65)
                   for a,b in zip(text,key))

def decrypt(text, key):
    return ''.join(chr((ord(a)-ord(b)+26)%26+65)
                   for a,b in zip(text,key))

text = input("Enter plaintext: ").upper()
key = generate_key(text, input("Enter keyword: ").upper())

cipher = encrypt(text,key)
print("Encrypted:",cipher)
print("Decrypted:",decrypt(cipher,key))