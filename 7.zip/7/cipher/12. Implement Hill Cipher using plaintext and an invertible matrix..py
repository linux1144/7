from sympy import Matrix

n = int(input("Enter matrix size: "))
K = Matrix([list(map(int,input().split())) for _ in range(n)])
P = input("Enter plaintext: ").upper()

if len(P) != n:
    print("Plaintext length must equal", n)
else:
    D = Matrix([ord(c)-65 for c in P])
    C = K * D % 26
    E = ''.join(chr(int(x)+65) for x in C)
    print("Encrypted:", E)
    print("Decrypted:", ''.join(chr(int(x)+65) for x in (K.inv_mod(26)*C)%26))