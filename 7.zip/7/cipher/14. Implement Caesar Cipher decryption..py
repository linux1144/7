text = input("Enter ciphertext: ")
key = int(input("Enter shift key: "))

plain = ''.join(chr((ord(c)-97-key)%26+97)
                if c.isalpha() and c.isascii() else c
                for c in text.lower())

print("Decrypted:", plain)