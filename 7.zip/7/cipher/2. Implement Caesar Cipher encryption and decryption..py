def caesar(text, key):
    return ''.join(chr((ord(c)-97+key)%26+97) if c.isalpha() else c for c in text.lower())

text = input("Enter plaintext: ")
key = int(input("Enter key (0-25): "))

enc = caesar(text, key)
print("Encrypted:", enc)
print("Decrypted:", caesar(enc, -key))