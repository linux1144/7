from flask import Flask, request
from math import gcd

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def rsa():
    if request.method == "POST":
        p, q = int(request.form["p"]), int(request.form["q"])
        msg = request.form["msg"]
        n, phi = p*q, (p-1)*(q-1)
        e = 3
        while gcd(e, phi) != 1:
            e += 2
        d = pow(e, -1, phi)
        enc = [pow(ord(c), e, n) for c in msg]
        dec = ''.join(chr(pow(c, d, n)) for c in enc)
        return f"Public Key: ({e},{n})<br>Private Key: ({d},{n})<br>Encrypted: {enc}<br>Decrypted: {dec}<br><a href='/'>Back</a>"

    return """
    <h2>RSA Encryption Dashboard</h2>
    <form method="post">
    Prime P: <input name="p" value="61"><br>
    Prime Q: <input name="q" value="53"><br>
    Message: <input name="msg"><br>
    <button>Encrypt & Decrypt</button>
    </form>
    """

app.run()