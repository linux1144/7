from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import hashlib

key = hashlib.sha256(input("Enter secret key: ").encode()).digest()[:16]
file = input("Enter text filename: ")

data = open(file, "rb").read()
cipher = AES.new(key, AES.MODE_CBC)
encrypted = cipher.iv + cipher.encrypt(pad(data, 16))
open(file+".bak", "wb").write(encrypted)

iv, data = encrypted[:16], encrypted[16:]
decrypted = unpad(AES.new(key, AES.MODE_CBC, iv).decrypt(data), 16)
open(file+".restored", "wb").write(decrypted)

print("Encrypted backup:", file+".bak")
print("Restored file:", file+".restored")