import socket, threading, hashlib
from Crypto.Cipher import AES

key = hashlib.sha256(input("Enter secret key: ").encode()).digest()

s = socket.socket()
mode = input("Server or Client (S/C): ").upper()

if mode == "S":
    s.bind(("0.0.0.0", 5000))
    s.listen(1)
    s, _ = s.accept()
else:
    s.connect((input("Server IP: "), 5000))

def receive():
    while True:
        n = int.from_bytes(s.recv(4), "big")
        data = b""
        while len(data) < n:
            data += s.recv(n-len(data))
        nonce, tag, ct = data[:16], data[16:32], data[32:]
        c = AES.new(key, AES.MODE_EAX, nonce)
        print("\nReceived:", c.decrypt_and_verify(ct, tag).decode())

threading.Thread(target=receive, daemon=True).start()

while True:
    msg = input("Message: ")
    c = AES.new(key, AES.MODE_EAX)
    ct, tag = c.encrypt_and_digest(msg.encode())
    data = c.nonce + tag + ct
    s.sendall(len(data).to_bytes(4,"big") + data)