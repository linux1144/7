import threading, queue, secrets

channel = queue.Queue()
key = secrets.token_bytes(16)

def sender():
    channel.put(key)
    print("Sender: 128-bit key sent")

def receiver():
    received = channel.get()
    print("Receiver: key received")
    print("Keys match:", received == key)

t1 = threading.Thread(target=sender)
t2 = threading.Thread(target=receiver)

t1.start(); t1.join()
t2.start(); t2.join()