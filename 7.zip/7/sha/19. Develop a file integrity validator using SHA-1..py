import hashlib

file = input("Enter filename: ")

with open(file, "rb") as f:
    digest = hashlib.sha1(f.read()).hexdigest()

print("SHA-1 Digest:", digest)