from Crypto.Cipher import DES
from Crypto.Random import get_random_bytes
import base64

key = get_random_bytes(8)

# Sender
text = input("Enter transaction: ").encode()
c = DES.new(key, DES.MODE_EAX)
ct, tag = c.encrypt_and_digest(text)
data = c.nonce + tag + ct

print("Encrypted transaction:", base64.b64encode(data).decode())

# Receiver
nonce, tag, ct = data[:16], data[16:32], data[32:]
d = DES.new(key, DES.MODE_EAX, nonce=nonce)
print("Received transaction:", d.decrypt_and_verify(ct, tag).decode())