from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

key = input("Enter 8-character key: ").encode()
mode = input("Encrypt or Decrypt (E/D): ").upper()
file = input("Enter filename: ")

if len(key) != 8:
    print("Key must be 8 bytes")
else:
    if mode == "E":
        iv = get_random_bytes(8)
        data = open(file, "rb").read()
        result = iv + DES.new(key, DES.MODE_CBC, iv).encrypt(pad(data, 8))
        output = file + ".des"
    else:
        data = open(file, "rb").read()
        iv, data = data[:8], data[8:]
        result = unpad(DES.new(key, DES.MODE_CBC, iv).decrypt(data), 8)
        output = file + ".dec"

    open(output, "wb").write(result)
    print("Saved:", output)