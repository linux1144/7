p = int(input("Enter prime p: "))
g = int(input("Enter generator g: "))

a = int(input("Alice private key: "))
b = int(input("Bob private key: "))

A = pow(g, a, p)
B = pow(g, b, p)

print("Alice public key:", A)
print("Bob public key:", B)

print("Alice shared key:", pow(B, a, p))
print("Bob shared key:", pow(A, b, p))